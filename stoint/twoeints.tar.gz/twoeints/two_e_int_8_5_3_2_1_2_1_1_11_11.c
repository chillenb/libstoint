#include <tgmath.h>

double two_e_int_8_5_3_2_1_2_1_1_11_11(double z12, double z34) {
  return (6912 * sqrt(0.2857142857142857) *
          (126 * pow(z12, 9) + 1512 * pow(z12, 8) * z34 + 8151 * pow(z12, 7) * pow(z34, 2) +
           25740 * pow(z12, 6) * pow(z34, 3) + 22880 * pow(z12, 5) * pow(z34, 4) + 14586 * pow(z12, 4) * pow(z34, 5) +
           6552 * pow(z12, 3) * pow(z34, 6) + 1976 * pow(z12, 2) * pow(z34, 7) + 360 * z12 * pow(z34, 8) +
           30 * pow(z34, 9))) /
         (pow(z12, 7) * pow(z34, 4) * pow(z12 + z34, 12));
}