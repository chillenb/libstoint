#include <tgmath.h>

double two_e_int_8_6_3_3_3_1_3_1_22_0(double z12, double z34) {
  return (-23040 * sqrt(42) *
          (99 * pow(z12, 8) + 1287 * pow(z12, 7) * z34 + 5742 * pow(z12, 6) * pow(z34, 2) +
           2574 * pow(z12, 5) * pow(z34, 3) + 8710 * pow(z12, 4) * pow(z34, 4) + 5122 * pow(z12, 3) * pow(z34, 5) +
           1626 * pow(z12, 2) * pow(z34, 6) + 286 * z12 * pow(z34, 7) + 22 * pow(z34, 8))) /
         (11. * pow(z12, 6) * pow(z34, 4) * pow(z12 + z34, 13));
}