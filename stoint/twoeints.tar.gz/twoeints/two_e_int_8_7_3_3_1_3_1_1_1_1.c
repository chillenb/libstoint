#include <tgmath.h>

double two_e_int_8_7_3_3_1_3_1_1_1_1(double z12, double z34) {
  return (13824 * sqrt(14) *
          (108 * pow(z12, 9) + 1512 * pow(z12, 8) * z34 + 9728 * pow(z12, 7) * pow(z34, 2) +
           37912 * pow(z12, 6) * pow(z34, 3) + 99008 * pow(z12, 5) * pow(z34, 4) + 51779 * pow(z12, 4) * pow(z34, 5) +
           19306 * pow(z12, 3) * pow(z34, 6) + 4889 * pow(z12, 2) * pow(z34, 7) + 756 * z12 * pow(z34, 8) +
           54 * pow(z34, 9))) /
         (pow(z12, 6) * pow(z34, 5) * pow(z12 + z34, 14));
}