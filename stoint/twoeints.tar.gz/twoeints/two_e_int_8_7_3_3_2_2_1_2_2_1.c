#include <tgmath.h>

double two_e_int_8_7_3_3_2_2_1_2_2_1(double z12, double z34) {
  return (138240 * sqrt(10) *
          (18 * pow(z12, 9) + 252 * pow(z12, 8) * z34 + 1598 * pow(z12, 7) * pow(z34, 2) +
           5992 * pow(z12, 6) * pow(z34, 3) + 14378 * pow(z12, 5) * pow(z34, 4) + 8099 * pow(z12, 4) * pow(z34, 5) +
           3136 * pow(z12, 3) * pow(z34, 6) + 809 * pow(z12, 2) * pow(z34, 7) + 126 * z12 * pow(z34, 8) +
           9 * pow(z34, 9))) /
         (pow(z12, 6) * pow(z34, 5) * pow(z12 + z34, 14));
}