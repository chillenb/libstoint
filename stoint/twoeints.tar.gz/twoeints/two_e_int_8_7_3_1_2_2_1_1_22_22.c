#include <tgmath.h>

double two_e_int_8_7_3_1_2_2_1_1_22_22(double z12, double z34) {
  return (-69120 * sqrt(0.2857142857142857) *
          (216 * pow(z12, 9) + 3024 * pow(z12, 8) * z34 + 19876 * pow(z12, 7) * pow(z34, 2) +
           81704 * pow(z12, 6) * pow(z34, 3) + 236236 * pow(z12, 5) * pow(z34, 4) + 113113 * pow(z12, 4) * pow(z34, 5) +
           40082 * pow(z12, 3) * pow(z34, 6) + 9883 * pow(z12, 2) * pow(z34, 7) + 1512 * z12 * pow(z34, 8) +
           108 * pow(z34, 9))) /
         (pow(z12, 6) * pow(z34, 5) * pow(z12 + z34, 14));
}