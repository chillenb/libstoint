#include <tgmath.h>

double two_e_int_8_8_2_2_3_3_0_2_0_22(double z12, double z34) {
  return (4147200 * sqrt(5) *
          (4 * pow(z12, 10) + 60 * pow(z12, 9) * z34 + 417 * pow(z12, 8) * pow(z34, 2) +
           1775 * pow(z12, 7) * pow(z34, 3) + 5145 * pow(z12, 6) * pow(z34, 4) + 10647 * pow(z12, 5) * pow(z34, 5) +
           5145 * pow(z12, 4) * pow(z34, 6) + 1775 * pow(z12, 3) * pow(z34, 7) + 417 * pow(z12, 2) * pow(z34, 8) +
           60 * z12 * pow(z34, 9) + 4 * pow(z34, 10))) /
         (pow(z12, 6) * pow(z34, 6) * pow(z12 + z34, 15));
}