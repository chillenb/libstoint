#include <tgmath.h>

double two_e_int_8_8_3_3_1_3_0_11_1_2(double z12, double z34) {
  return (-829440 * sqrt(105) *
          (2 * pow(z12, 10) + 30 * pow(z12, 9) * z34 + 205 * pow(z12, 8) * pow(z34, 2) +
           835 * pow(z12, 7) * pow(z34, 3) + 2205 * pow(z12, 6) * pow(z34, 4) + 3731 * pow(z12, 5) * pow(z34, 5) +
           2205 * pow(z12, 4) * pow(z34, 6) + 835 * pow(z12, 3) * pow(z34, 7) + 205 * pow(z12, 2) * pow(z34, 8) +
           30 * z12 * pow(z34, 9) + 2 * pow(z34, 10))) /
         (pow(z12, 6) * pow(z34, 6) * pow(z12 + z34, 15));
}