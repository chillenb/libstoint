#include <tgmath.h>

double two_e_int_8_8_3_3_1_3_1_11_1_3(double z12, double z34) {
  return (-552960 * sqrt(210) *
          (9 * pow(z12, 10) + 135 * pow(z12, 9) * z34 + 940 * pow(z12, 8) * pow(z34, 2) +
           4020 * pow(z12, 7) * pow(z34, 3) + 11760 * pow(z12, 6) * pow(z34, 4) + 24752 * pow(z12, 5) * pow(z34, 5) +
           11760 * pow(z12, 4) * pow(z34, 6) + 4020 * pow(z12, 3) * pow(z34, 7) + 940 * pow(z12, 2) * pow(z34, 8) +
           135 * z12 * pow(z34, 9) + 9 * pow(z34, 10))) /
         (pow(z12, 6) * pow(z34, 6) * pow(z12 + z34, 15));
}