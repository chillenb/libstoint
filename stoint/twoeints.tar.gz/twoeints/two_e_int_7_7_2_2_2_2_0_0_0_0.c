#include <tgmath.h>

double two_e_int_7_7_2_2_2_2_0_0_0_0(double z12, double z34) {
  return (103680 *
          (245 * pow(z12, 12) + 3185 * pow(z12, 11) * z34 + 19158 * pow(z12, 10) * pow(z34, 2) +
           70694 * pow(z12, 9) * pow(z34, 3) + 179359 * pow(z12, 8) * pow(z34, 4) + 334763 * pow(z12, 7) * pow(z34, 5) +
           489060 * pow(z12, 6) * pow(z34, 6) + 334763 * pow(z12, 5) * pow(z34, 7) +
           179359 * pow(z12, 4) * pow(z34, 8) + 70694 * pow(z12, 3) * pow(z34, 9) + 19158 * pow(z12, 2) * pow(z34, 10) +
           3185 * z12 * pow(z34, 11) + 245 * pow(z34, 12))) /
         (7. * pow(z12, 7) * pow(z34, 7) * pow(z12 + z34, 13));
}