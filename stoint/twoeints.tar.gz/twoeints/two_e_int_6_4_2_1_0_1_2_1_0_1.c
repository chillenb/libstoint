#include <tgmath.h>

double two_e_int_6_4_2_1_0_1_2_1_0_1(double z12, double z34) {
  return (96 * sqrt(30) *
          (7 * pow(z12, 6) + 63 * pow(z12, 5) * z34 + 252 * pow(z12, 4) * pow(z34, 2) +
           168 * pow(z12, 3) * pow(z34, 3) + 72 * pow(z12, 2) * pow(z34, 4) + 18 * z12 * pow(z34, 5) +
           2 * pow(z34, 6))) /
         (pow(z12, 5) * pow(z34, 3) * pow(z12 + z34, 9));
}