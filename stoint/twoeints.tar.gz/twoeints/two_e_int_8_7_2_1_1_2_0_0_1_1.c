#include <tgmath.h>

double two_e_int_8_7_2_1_1_2_0_0_1_1(double z12, double z34) {
  return (69120 * sqrt(3) *
          (588 * pow(z12, 11) + 8232 * pow(z12, 10) * z34 + 52617 * pow(z12, 9) * pow(z34, 2) +
           201558 * pow(z12, 8) * pow(z34, 3) + 507507 * pow(z12, 7) * pow(z34, 4) +
           852852 * pow(z12, 6) * pow(z34, 5) + 666848 * pow(z12, 5) * pow(z34, 6) +
           362908 * pow(z12, 4) * pow(z34, 7) + 138152 * pow(z12, 3) * pow(z34, 8) + 35348 * pow(z12, 2) * pow(z34, 9) +
           5488 * z12 * pow(z34, 10) + 392 * pow(z34, 11))) /
         (7. * pow(z12, 7) * pow(z34, 6) * pow(z12 + z34, 14));
}