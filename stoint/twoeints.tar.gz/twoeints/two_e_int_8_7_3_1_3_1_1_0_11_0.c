#include <tgmath.h>

double two_e_int_8_7_3_1_3_1_1_0_11_0(double z12, double z34) {
  return (-13824 * (864 * pow(z12, 9) + 12096 * pow(z12, 8) * z34 + 84124 * pow(z12, 7) * pow(z34, 2) +
                    391496 * pow(z12, 6) * pow(z34, 3) + 1365364 * pow(z12, 5) * pow(z34, 4) +
                    557557 * pow(z12, 4) * pow(z34, 5) + 176498 * pow(z12, 3) * pow(z34, 6) +
                    40687 * pow(z12, 2) * pow(z34, 7) + 6048 * z12 * pow(z34, 8) + 432 * pow(z34, 9))) /
         (pow(z12, 6) * pow(z34, 5) * pow(z12 + z34, 14));
}