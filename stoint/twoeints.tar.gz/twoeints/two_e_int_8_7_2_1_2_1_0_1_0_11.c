#include <tgmath.h>

double two_e_int_8_7_2_1_2_1_0_1_0_11(double z12, double z34) {
  return (-138240 *
          (147 * pow(z12, 11) + 2058 * pow(z12, 10) * z34 + 14268 * pow(z12, 9) * pow(z34, 2) +
           65982 * pow(z12, 8) * pow(z34, 3) + 228228 * pow(z12, 7) * pow(z34, 4) + 618618 * pow(z12, 6) * pow(z34, 5) +
           314132 * pow(z12, 5) * pow(z34, 6) + 127582 * pow(z12, 4) * pow(z34, 7) + 40208 * pow(z12, 3) * pow(z34, 8) +
           9242 * pow(z12, 2) * pow(z34, 9) + 1372 * z12 * pow(z34, 10) + 98 * pow(z34, 11))) /
         (7. * pow(z12, 7) * pow(z34, 6) * pow(z12 + z34, 14));
}