#include <tgmath.h>

double two_e_int_8_6_3_3_2_2_1_1_22_22(double z12, double z34) {
  return (34560 * (1540 * pow(z12, 12) + 20020 * pow(z12, 11) * z34 + 119724 * pow(z12, 10) * pow(z34, 2) +
                   435292 * pow(z12, 9) * pow(z34, 3) + 1070432 * pow(z12, 8) * pow(z34, 4) +
                   1871584 * pow(z12, 7) * pow(z34, 5) + 1919840 * pow(z12, 6) * pow(z34, 6) +
                   1461447 * pow(z12, 5) * pow(z34, 7) + 818971 * pow(z12, 4) * pow(z34, 8) +
                   329186 * pow(z12, 3) * pow(z34, 9) + 90002 * pow(z12, 2) * pow(z34, 10) +
                   15015 * z12 * pow(z34, 11) + 1155 * pow(z34, 12))) /
         (11. * pow(z12, 8) * pow(z34, 6) * pow(z12 + z34, 13));
}