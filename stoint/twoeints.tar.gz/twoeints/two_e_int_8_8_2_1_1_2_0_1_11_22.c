#include <tgmath.h>

double two_e_int_8_8_2_1_1_2_0_1_11_22(double z12, double z34) {
  return (2488320 * sqrt(6) *
          (49 * pow(z12, 12) + 735 * pow(z12, 11) * z34 + 5178 * pow(z12, 10) * pow(z34, 2) +
           22790 * pow(z12, 9) * pow(z34, 3) + 70350 * pow(z12, 8) * pow(z34, 4) + 162162 * pow(z12, 7) * pow(z34, 5) +
           290290 * pow(z12, 6) * pow(z34, 6) + 162162 * pow(z12, 5) * pow(z34, 7) + 70350 * pow(z12, 4) * pow(z34, 8) +
           22790 * pow(z12, 3) * pow(z34, 9) + 5178 * pow(z12, 2) * pow(z34, 10) + 735 * z12 * pow(z34, 11) +
           49 * pow(z34, 12))) /
         (7. * pow(z12, 7) * pow(z34, 7) * pow(z12 + z34, 15));
}